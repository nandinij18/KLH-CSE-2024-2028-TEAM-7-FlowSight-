import random
import time
from datetime import datetime


# Traffic sensors
sensors = [
    {"sensor_id": "S001", "road_name": "MG Road"},
    {"sensor_id": "S002", "road_name": "Hitech City Road"},
    {"sensor_id": "S003", "road_name": "Banjara Hills Road"},
    {"sensor_id": "S004", "road_name": "Kukatpally Road"},
    {"sensor_id": "S005", "road_name": "Jubilee Hills Road"}
]


def generate_traffic_event():
    sensor = random.choice(sensors)

    vehicle_count = random.randint(20, 250)
    average_speed = round(random.uniform(10, 70), 2)

    event = {
        "sensor_id": sensor["sensor_id"],
        "road_name": sensor["road_name"],
        "timestamp": datetime.now().isoformat(),
        "vehicle_count": vehicle_count,
        "average_speed": average_speed
    }

    return event


while True:

    traffic_event = generate_traffic_event()

    print(
        f"Sensor: {traffic_event['sensor_id']} | "
        f"Road: {traffic_event['road_name']} | "
        f"Vehicles: {traffic_event['vehicle_count']} | "
        f"Speed: {traffic_event['average_speed']} km/h | "
        f"Time: {traffic_event['timestamp']}"
    )

    time.sleep(2)