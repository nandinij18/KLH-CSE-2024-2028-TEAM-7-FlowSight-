import json
import time
import random
from datetime import datetime
from kafka import KafkaProducer


# Kafka configuration
KAFKA_SERVER = "localhost:9092"
TOPIC_NAME = "traffic-events"


# Create Kafka producer
producer = KafkaProducer(
    bootstrap_servers=KAFKA_SERVER,
    value_serializer=lambda value: json.dumps(value).encode("utf-8")
)


# Traffic sensors
sensors = [
    {"sensor_id": "S001", "road_name": "MG Road"},
    {"sensor_id": "S002", "road_name": "Hitech City Road"},
    {"sensor_id": "S003", "road_name": "Banjara Hills Road"},
    {"sensor_id": "S004", "road_name": "Kukatpally Road"},
    {"sensor_id": "S005", "road_name": "Jubilee Hills Road"}
]


def generate_traffic_event():

    sensor = random.choice(sensors)

    vehicle_count = random.randint(20, 250)

    average_speed = round(
        random.uniform(10, 70),
        2
    )

    event = {
        "sensor_id": sensor["sensor_id"],
        "road_name": sensor["road_name"],
        "timestamp": datetime.now().isoformat(),
        "vehicle_count": vehicle_count,
        "average_speed": average_speed
    }

    return event


print("Kafka Producer Started...")
print("Sending traffic events to Kafka...")
print("Press Ctrl+C to stop.\n")


try:

    while True:

        traffic_event = generate_traffic_event()

        # Send event to Kafka
        producer.send(
            TOPIC_NAME,
            value=traffic_event
        )

        # Make sure the message is sent
        producer.flush()

        print(
            f"Sent: "
            f"{traffic_event}"
        )

        time.sleep(2)


except KeyboardInterrupt:

    print("\nProducer stopped by user.")


finally:

    producer.close()
    print("Kafka Producer closed.")