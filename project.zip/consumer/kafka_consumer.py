import json
from datetime import datetime

from kafka import KafkaConsumer
import psycopg2


# ============================================================
# KAFKA CONFIGURATION
# ============================================================

KAFKA_SERVER = "localhost:9092"
TOPIC_NAME = "traffic-events"


# ============================================================
# POSTGRESQL CONFIGURATION
# ============================================================

DB_HOST = "localhost"
DB_NAME = "flowsight"
DB_USER = "postgres"
DB_PASSWORD = "nandu@555777"
DB_PORT = "5432"


# ============================================================
# CONNECT TO POSTGRESQL
# ============================================================

try:

    connection = psycopg2.connect(
        host=DB_HOST,
        database=DB_NAME,
        user=DB_USER,
        password=DB_PASSWORD,
        port=DB_PORT
    )

    cursor = connection.cursor()

    print("======================================")
    print(" Connected to PostgreSQL successfully!")
    print("======================================\n")

except psycopg2.Error as error:

    print("Could not connect to PostgreSQL.")
    print("Error:", error)
    exit()


# ============================================================
# DATA VALIDATION
# ============================================================

def validate_traffic_event(event):

    # Required fields
    required_fields = [
        "sensor_id",
        "road_name",
        "timestamp",
        "vehicle_count",
        "average_speed"
    ]

    # Check whether required fields exist
    for field in required_fields:

        if field not in event:

            return False, f"Missing field: {field}"


    # Check sensor ID
    if not event["sensor_id"]:

        return False, "Sensor ID cannot be empty"


    # Check road name
    if not event["road_name"]:

        return False, "Road name cannot be empty"


    # Check vehicle count
    if event["vehicle_count"] < 0:

        return False, "Vehicle count cannot be negative"


    # Check speed
    if event["average_speed"] < 0:

        return False, "Speed cannot be negative"

    if event["average_speed"] > 150:

        return False, "Speed is unrealistically high"


    # Check timestamp
    try:

        datetime.fromisoformat(event["timestamp"])

    except ValueError:

        return False, "Invalid timestamp"


    return True, "Valid"


# ============================================================
# DATA TRANSFORMATION
# ============================================================

def transform_traffic_event(event):

    # Convert timestamp string into datetime
    timestamp = datetime.fromisoformat(
        event["timestamp"]
    )


    # Extract time information
    event["hour"] = timestamp.hour

    event["day"] = timestamp.day

    event["month"] = timestamp.month

    event["year"] = timestamp.year


    # Find weekday
    event["weekday"] = timestamp.strftime("%A")


    # Check whether it is weekend
    event["is_weekend"] = timestamp.weekday() >= 5


    # ========================================================
    # CONGESTION CLASSIFICATION
    # ========================================================

    vehicle_count = event["vehicle_count"]

    average_speed = event["average_speed"]


    if vehicle_count > 200 and average_speed < 20:

        event["congestion_level"] = "High"


    elif vehicle_count > 120 and average_speed < 35:

        event["congestion_level"] = "Medium"


    else:

        event["congestion_level"] = "Low"


    return event


# ============================================================
# INSERT DATA INTO POSTGRESQL
# ============================================================

def insert_into_database(event):

    insert_query = """
        INSERT INTO traffic_data (
            sensor_id,
            road_name,
            timestamp,
            vehicle_count,
            average_speed,
            hour,
            day,
            month,
            year,
            weekday,
            is_weekend,
            congestion_level
        )
        VALUES (
            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s,
            %s
        )
    """


    values = (
        event["sensor_id"],
        event["road_name"],
        datetime.fromisoformat(event["timestamp"]),
        event["vehicle_count"],
        event["average_speed"],
        event["hour"],
        event["day"],
        event["month"],
        event["year"],
        event["weekday"],
        event["is_weekend"],
        event["congestion_level"]
    )


    cursor.execute(
        insert_query,
        values
    )

    connection.commit()


# ============================================================
# CREATE KAFKA CONSUMER
# ============================================================

consumer = KafkaConsumer(

    TOPIC_NAME,

    bootstrap_servers=KAFKA_SERVER,

    value_deserializer=lambda value:
        json.loads(
            value.decode("utf-8")
        ),

    auto_offset_reset="earliest",

    enable_auto_commit=True,

    group_id="flowsight-consumer"
)


# ============================================================
# START CONSUMER
# ============================================================

print("======================================")
print(" FlowSight Kafka Consumer")
print("======================================")
print("Waiting for traffic events...\n")


try:

    for message in consumer:

        # Get event from Kafka
        traffic_event = message.value


        # ====================================================
        # VALIDATION
        # ====================================================

        is_valid, validation_message = (
            validate_traffic_event(
                traffic_event
            )
        )


        if not is_valid:

            print(
                f"❌ Invalid data: "
                f"{validation_message}"
            )

            continue


        # ====================================================
        # TRANSFORMATION
        # ====================================================

        clean_event = transform_traffic_event(
            traffic_event
        )


        # ====================================================
        # SAVE TO POSTGRESQL
        # ====================================================

        insert_into_database(
            clean_event
        )


        # ====================================================
        # DISPLAY RESULT
        # ====================================================

        print(
            f"✅ Stored | "
            f"Sensor: {clean_event['sensor_id']} | "
            f"Road: {clean_event['road_name']} | "
            f"Vehicles: {clean_event['vehicle_count']} | "
            f"Speed: {clean_event['average_speed']} km/h | "
            f"Congestion: {clean_event['congestion_level']} | "
            f"Hour: {clean_event['hour']} | "
            f"Weekend: {clean_event['is_weekend']}"
        )


# ============================================================
# STOP WITH CTRL+C
# ============================================================

except KeyboardInterrupt:

    print("\n")
    print("Consumer stopped by user.")


# ============================================================
# CLOSE CONNECTIONS
# ============================================================

finally:

    consumer.close()

    cursor.close()

    connection.close()

    print("Kafka Consumer closed.")

    print("PostgreSQL connection closed.")